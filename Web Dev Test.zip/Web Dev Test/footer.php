<footer class="homes-footer d-flex justify-content-end m-1">
    <div class="d-flex homes-footer-div align-items-center">
        <ul class="d-flex homes-footer-nav footer-text">
            <li class="px-3"><a href="#About Us">About Us</a></li>
            <li class="px-3"><a href="#Services">Our Services</a></li>
            <li class="px-3"><a href="#Contact Us">Contact Us</a></li>
        </ul>
        <p class="ml-5 copyright-text">Copyright &#169 2020 M. Butler Custom Homes - All rights reserved</p>
    </div>
</footer>
<?php wp_footer(); ?> 